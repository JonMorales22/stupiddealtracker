// Load the AWS SDK for Node.js
var AWS = require('aws-sdk');
// Set the region 
AWS.config.update({region: 'us-east-1'});

// Create sendEmail params 
var params = {
  Destination: { /* required */
    // CcAddresses: [
    //   'EMAIL_ADDRESS',
    //   /* more items */
    // ],
    ToAddresses: [
      'jonmorales2.718@gmail.com',
      /* more items */
    ]
  },
  Message: { /* required */
    Body: { /* required */
    //   Html: {
    //    Charset: "UTF-8",
    //    Data: "HTML_FORMAT_BODY"
    //   },
      Text: {
       Charset: "UTF-8",
       Data: "TEXT_FORMAT_BODY"
      }
     },
     Subject: {
      Charset: 'UTF-8',
      Data: 'Test email'
     }
    },
  Source: 'jonmorales22@gmail.com', /* required */
//   ReplyToAddresses: [
//      'EMAIL_ADDRESS',
//     /* more items */
//   ],
};

// Create the promise and SES service object
// var sendPromise = new AWS.SES({apiVersion: '2010-12-01'}).sendEmail(params).promise();

// Handle promise's fulfilled/rejected states
// sendPromise.then(
//   function(data) {
//     console.log(data.MessageId);
//   }).catch(
//     function(err) {
//     console.error(err, err.stack);
//   });



//========================
//RIPPED FROM MUSICIANSFRIENDNOTIFIER.JS!!!!
        // const ses = new SES();

        // const params: SendEmailRequest = {
        //     Source: "jonmorales2.718@gmail.com",
        //     Destination: {
        //         ToAddresses: [
        //             "jonmorales22@gmail.com"
        //         ]
        //     },
        //     Message: {
        //         Subject: {
        //             Data: "Musicians Friend Tracker",
        //             Charset: "UTF-8"
        //         },
        //         Body: {
        //             Text: {
        //                 Data: "We found something you're looking for!",
        //                 Charset: "UTF-8"
        //             }
        //             // Html: {
        //             //     Data: "HTML_FORMAT_BODY",
        //             //     Charset: "UTF-8"
        //             // }
        //         }
        //     }
        // }
        // return new Promise((resolve, reject) => {
        //     ses.sendEmail(params, (err: AWSError, data: SendEmailResponse) => {
        //         if (err) {
        //             console.log(err, err.stack);
        //             return reject(err)
        //         }
        //         else 
        //             return resolve(data);
        //       });
        // })
        // ses.sendEmail(params, (err: AWSError, data: SendEmailResponse) => {
        //     if (err) {
        //         console.log(err, err.stack);
        //         throw(err);   
        //     }
        //     else 
        //         console.log(data);
        //   });

//=================================================

  export class AmazonNotifier {
      sendPromise;
      constructor() {
          this.sendPromise = new AWS.SES({apiVersion: '2010-12-01'});
      }

      async sendEmail() {
          try{
            var ass = await this.sendPromise.sendEmail(params)
            console.log(ass.MessageId);
          }
          catch(e) {
            throw e;
          }
      }
  }